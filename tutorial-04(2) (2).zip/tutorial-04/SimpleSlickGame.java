import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class SimpleSlickGame extends BasicGame {
	public final static int TEXT_OFFSET = 100;
	public final static int SCREEN_WIDTH = 1024;
	public final static int SCREEN_HEIGHT = 768;

	// Here are some instance variables. Can you define your own
	// to help solve the problems?
	private int count = 0;
	private Image background;

	public SimpleSlickGame() {
		super("SimpleSlickGame");
	}

	// Remember, this method is only ever run *once*.
	@Override
	public void init(GameContainer container) throws SlickException {
		background = new Image("assets/background.jpg");
	}

	@Override
	public void update(GameContainer gc, int delta) throws SlickException {
		Input input = gc.getInput();

		// Have a read of the isKeyDown method's documentation.
		if (input.isKeyDown(Input.KEY_UP)) {
			count++;
		}

		if (input.isKeyDown(Input.KEY_DOWN)) {
			count--;
		}
	}

	// If you want to draw something on the screen, it *must* be done in this method.
	@Override
	public void render(GameContainer container, Graphics g) throws SlickException {
		background.draw(0, 0);
		g.drawString("Count = " + count, TEXT_OFFSET, TEXT_OFFSET);
	}

	// Don't forget to change the class name here if you create another Slick class...
	public static void main(String[] args) {
		try {
			AppGameContainer app = new AppGameContainer(new SimpleSlickGame());
			app.setDisplayMode(SCREEN_WIDTH, SCREEN_HEIGHT, false);
			app.setShowFPS(true);
			app.start();
		} catch (SlickException e) {
			e.printStackTrace();
		}
	}
}