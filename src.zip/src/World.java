import java.util.ArrayList;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;


public class World {
	
	private static final int SCREEN_WIDTH = 1024;
	
	private Character player;
	// All relevant image source files.
	private final String frogFile = "assets/frog.png";
	private final String grassFile = "assets/grass.png";
	private final String waterFile = "assets/water.png";
	private final String busFile = "assets/bus.png";
	
	private final float[] frogStartPosition = {512, 720};
	/** y-coordinates for rows of grass tiles. */
	private final float[] grassYPositions = {672, 384};
	/** The y-coordinate bounds within which water tiles lie. */
	private final float[] waterYBounds = {336, 48};
 	/** The y-coordinates of each row containing buses. */
	private final float[] busRowStartingYPos = {432, 480, 528, 576, 624};
	/** Offsets of initial buses for each bus row. */
	private final float[] busRowOffsets = {48, 0, 64, 128, 250};
	/** Separation distance between buses for each bus row. */
	private final float[] busRowSeparationDist = {6.5f, 5, 12, 5, 6.5f};
	
	// Arrays containing all sprites that are not the character.
	ArrayList<Tile> waterTiles = new ArrayList<Tile>();
	ArrayList<Bus> buses = new ArrayList<Bus>();
	ArrayList<Tile> grassTiles = new ArrayList<Tile>();
	
	
	public World() throws SlickException {
		// Perform initialisation logic
		
		// Initialise array-lists of grass and water tiles.
		setupTiles(grassTiles, waterTiles);
		
		// Initialises buses and their starting positions.
		this.setupBusRow(busRowStartingYPos[0], busRowOffsets[0], busRowSeparationDist[0], false);
		this.setupBusRow(busRowStartingYPos[1], busRowOffsets[1], busRowSeparationDist[1], true);
		this.setupBusRow(busRowStartingYPos[2], busRowOffsets[2], busRowSeparationDist[2], false);
		this.setupBusRow(busRowStartingYPos[3], busRowOffsets[3], busRowSeparationDist[3], true);
		this.setupBusRow(busRowStartingYPos[4], busRowOffsets[4], busRowSeparationDist[4], false);
		
		// Instantiate the frog character.
		player = new Character(frogFile, frogStartPosition[0], frogStartPosition[1]);
	}
	
	
	public void update(Input input, int delta) {
		// Update all of the sprites in the game
		
		// Checks whether player is colliding with water or a bus.
		player.collisionChecker(waterTiles, buses);
		// Updates player position based upon key presses.
		player.update(input);
		
		// Updates bus positions.
		for(int i=0;i<buses.size();i++) {
			buses.get(i).update(input, delta);
		}	
	}
	
	
	public void render(Graphics g) throws SlickException {
		// Draw all of the sprites in the game
		
		// Drawing Grass 
		for(int i=0;i<grassTiles.size();i++) {
			Tile tile = grassTiles.get(i);
			tile.render();
		}
		
		// Drawing Water
		for(int i=0;i<waterTiles.size();i++) {
			Tile tile = waterTiles.get(i);
			tile.render();
		}
		
		// Drawing Character
		player.render();
		
		// Drawing buses
		
		for(int i=0;i<buses.size();i++) {
			buses.get(i).render();
		}
	}
	
	
	private void setupBusRow(float yStart, float offset, float separationDist, boolean direction) throws SlickException {
		// Sets up initial positions of a row of buses, adding new buses to array.
		
		float xLocation=0;
		if(!direction) {
			// if buses are travelling to the left...
			xLocation = SCREEN_WIDTH - offset;
			while(xLocation > 0) {
				Bus bus = new Bus(busFile, xLocation, yStart, direction);
				xLocation -= (separationDist*Sprite.SPRITE_SIZE);
				buses.add(bus);
			}
		}
		
		else {
			// if buses are travelling to the right...
			xLocation += offset; 
			while(xLocation < SCREEN_WIDTH) {
				Bus bus = new Bus(busFile, xLocation, yStart, direction);
				xLocation += (separationDist*Sprite.SPRITE_SIZE);
				buses.add(bus);
			}
		}
	}
	
	
	private void setupTiles(ArrayList<Tile> grassTiles, ArrayList<Tile> waterTiles) throws SlickException {
		// Initialising all of the grass tiles.
		
		float xPos=0;
		for(int i=0; i<=SCREEN_WIDTH/Sprite.SPRITE_SIZE;i++) {
			Tile tile = new Tile(grassFile, xPos, grassYPositions[0]);
			grassTiles.add(tile);
			tile = new Tile(grassFile, xPos, grassYPositions[1]);
			grassTiles.add(tile);
			xPos+=Sprite.SPRITE_SIZE;
		}
		
		// Initialising all of the water tiles.
		float yPos=waterYBounds[0];
		xPos = 0;
		for(int i=0; i<((waterYBounds[0]-Sprite.SPRITE_SIZE)/Sprite.SPRITE_SIZE);i++) {
			for(int j=0;j<=SCREEN_WIDTH/Sprite.SPRITE_SIZE;j++) {
				Tile tile = new Tile(waterFile, xPos, yPos);
				waterTiles.add(tile);
				xPos+=Sprite.SPRITE_SIZE;
			}
			xPos = 0;
			yPos-=Sprite.SPRITE_SIZE;
		}
	}
}

