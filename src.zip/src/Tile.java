import org.newdawn.slick.SlickException;

public class Tile extends Sprite{

	public Tile(String imageSrc, float x, float y) throws SlickException {
		super(imageSrc, x, y);
	}
}
