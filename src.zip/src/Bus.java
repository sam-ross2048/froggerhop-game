import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Bus extends Sprite{
	
	private static final float speed = 0.15f;
	// Determines which side bus travels from (left = true, right = false)
	private boolean startPos;
	
	
	public Bus(String imageSrc, float x, float y, boolean startPos) throws SlickException {
		super(imageSrc, x, y);
		this.startPos = startPos;
	}
	
	
	public void update(Input input, int delta) {
		// Updates the bus positions.
		
		if(startPos) {
			// if bus travels from the left...
			if((this.getX() + delta*speed)<SCREEN_WIDTH + SPRITE_SIZE/2) {
				this.setX(this.getX() + delta*speed);
				this.setBox(this.getX(), this.getY());
			}
			else {
				this.setX(-SPRITE_SIZE/2);
				this.setBox(this.getX(), this.getY());
			}
		}
		else {
			// if bus travels from the right...
			if((this.getX() - delta*speed)>(-SPRITE_SIZE/2)){
				this.setX(this.getX() - delta*speed);
				this.setBox(this.getX(), this.getY());
			}
			else {
				this.setX(SCREEN_WIDTH + SPRITE_SIZE/2);
				this.setBox(getX(), getY());
			}
		}
	}
}
