
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

import utilities.BoundingBox;


public class Sprite {
	
	public static final int SCREEN_WIDTH = 1024;
	public static final int SCREEN_HEIGHT = 768;
	
	private float xPos;
	private float yPos;
	private Image image;
	private BoundingBox box;
	
	public final static int SPRITE_SIZE = 48;
	
	public Sprite(String imageSrc, float x, float y) throws SlickException {
		xPos = x;
		yPos = y;
		image = new Image(imageSrc);
		this.box = new BoundingBox(x, y, SPRITE_SIZE, SPRITE_SIZE);	
	}
	
	
	public void render() throws SlickException{
		image.drawCentered(xPos, yPos);
	}
	
	
	public Image getImage() {
		return image;
	}
	
	
	public void setX(float x) {
		xPos = x;
	}
	
	
	public float getX() {
		return xPos;
	}
	
	
	public void setY(float y) {
		yPos = y;
	}
	
	
	public float getY() {
		return yPos;
	}
	
	
	public void setBox(float x, float y) {
		this.box.setX(x);
		this.box.setY(y);
	}
	
	
	public BoundingBox getBox() {
		return box;
	}
}
