import java.util.ArrayList;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Character extends Sprite{
	
	public Character(String imageSrc, float x, float y) throws SlickException {
		super(imageSrc, x, y);
	}
	
	
	public void collisionChecker(ArrayList<Tile> waterTiles, ArrayList<Bus> buses) {
		
		for(int i=0;i<waterTiles.size();i++) {
			if(this.getBox().intersects(waterTiles.get(i).getBox())) {
				System.exit(0);
			}
		}
		for(int i=0;i<buses.size();i++) {
			if(this.getBox().intersects(buses.get(i).getBox())) {
				System.exit(0);
			}
		}
	}
	
	
	public void update(Input input){
		// Updates the character's position based upon key-inputs by the user.
		if (input.isKeyPressed(Input.KEY_UP) && this.getY() - SPRITE_SIZE >= 0) {
			this.setY(this.getY() - SPRITE_SIZE);
		}

		if (input.isKeyPressed(Input.KEY_DOWN) && this.getY() + SPRITE_SIZE < SCREEN_HEIGHT) {
			this.setY(this.getY() + SPRITE_SIZE);
		}
		
		if (input.isKeyPressed(Input.KEY_LEFT) && this.getX() - SPRITE_SIZE >= 0) {
			setX(this.getX() - SPRITE_SIZE);
		}
		if(input.isKeyPressed(Input.KEY_RIGHT) && this.getX() + SPRITE_SIZE <= SCREEN_WIDTH) {
			setX(getX() + SPRITE_SIZE);
		}
		this.setBox(this.getX(), this.getY());
		//super.box.setX(this.getX());
		//super.box.setY(this.getY());
	}
}
